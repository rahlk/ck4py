<?xml version="1.0" encoding="UTF-8"?>
<Metrics scope="netbeans-7.3_api.java" type="Project" date="2013-06-13" xmlns="http://metrics.sourceforge.net/2003/Metrics-First-Flat">
   <Cycle name="org.netbeans.spi.java.queries et al" nodes="2" diameter="1">
      <Package>org.netbeans.spi.java.queries</Package>
      <Package>org.netbeans.api.java.queries</Package>
   </Cycle>
   <Metric id = "VG" description ="McCabe Cyclomatic Complexity" max ="10" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "1.738" stddev = "1.659" max = "8">
         <Value name="getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="8"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="7"/>
         <Value name="attach" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="7"/>
         <Value name="findSources" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="findUnitTests" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQuery.Result#addChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="getSourceLevel2" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="normalize" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQuery.Result#getDelegate" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="SourceLevelQuery.Result#getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="SourceLevelQuery.Result#removeChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="findSource" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.Result#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.Result#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.Result#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="attachSources" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[#stateChanged" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#supportsChanges" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findSources" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findUnitTests" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="attachSources" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#addChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#removeChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findSource" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "PAR" description ="Number of Parameters" max ="5" hint ="Move invoked method or pass an object">
      <Values per = "method" avg = "0.721" stddev = "0.656" max = "3">
         <Value name="attach" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="attachSources" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="attachSources" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.Result#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.Result#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#addChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[#stateChanged" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#removeChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="getSourceLevel2" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="normalize" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findSources" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findSource" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findUnitTests" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findSources" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findUnitTests" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#addChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#removeChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findSource" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result#getDelegate" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result#getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result#supportsChanges" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NBD" description ="Nested Block Depth" max ="5" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "0.984" stddev = "1.18" max = "5">
         <Value name="getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="5"/>
         <Value name="attach" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="SourceLevelQuery.Result#addChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="getSourceLevel2" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="findSources" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="findUnitTests" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQuery.Result#removeChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="normalize" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="attachSources" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[#stateChanged" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#getDelegate" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#supportsChanges" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findSource" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findSources" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findUnitTests" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="attachSources" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#addChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#removeChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findSource" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "CA" description ="Afferent Coupling">
      <Values per = "packageFragment" avg = "5" stddev = "2.944" max = "8">
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="8"/>
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="6"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "CE" description ="Efferent Coupling">
      <Values per = "packageFragment" avg = "4.667" stddev = "3.399" max = "8">
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="8"/>
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMI" description ="Instability">
      <Values per = "packageFragment" avg = "0.333" stddev = "0.243" max = "0.571">
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="0.571"/>
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="0.429"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMA" description ="Abstractness">
      <Values per = "packageFragment" avg = "0.417" stddev = "0.425" max = "1">
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="0.25"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMD" description ="Normalized Distance">
      <Values per = "packageFragment" avg = "0.631" stddev = "0.28" max = "1">
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="1"/>
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="0.571"/>
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="0.321"/>
      </Values>
   </Metric>
   <Metric id = "DIT" description ="Depth of Inheritance Tree">
      <Values per = "type" avg = "0.522" stddev = "0.58" max = "2">
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="1"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "WMC" description ="Weighted methods per Class">
      <Values per = "type" total = "106" avg = "4.609" stddev = "4.669" max = "17">
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="17"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="15"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="12"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="10"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="8"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="5"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="3"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSC" description ="Number of Children">
      <Values per = "type" total = "24" avg = "1.043" stddev = "1.334" max = "4">
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="3"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="3"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NORM" description ="Number of Overridden Methods">
      <Values per = "type" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "LCOM" description ="Lack of Cohesion of Methods">
      <Values per = "type" avg = "0.033" stddev = "0.153" max = "0.75">
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0.75"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOF" description ="Number of Attributes">
      <Values per = "type" total = "5" avg = "0.217" stddev = "0.72" max = "3">
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSF" description ="Number of Static Attributes">
      <Values per = "type" total = "16" avg = "0.696" stddev = "1.231" max = "5">
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="5"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="2"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOM" description ="Number of Methods">
      <Values per = "type" total = "48" avg = "2.087" stddev = "1.886" max = "7">
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="7"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="3"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="2"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSM" description ="Number of Static Methods">
      <Values per = "type" total = "13" avg = "0.565" stddev = "1.135" max = "4">
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "SIX" description ="Specialization Index">
      <Values per = "type" avg = "0" stddev = "0" max = "0">
         <Value name="JavaClassPathConstants" source ="JavaClassPathConstants.java" package ="org.netbeans.api.java.classpath" value ="0"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Trigger" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AccessibilityQueryImplementation" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQueryImplementation" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQueryImplementation" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="MultipleRootsUnitTestForSourceQueryImplementation" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacherImplementation" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQueryImplementation" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOC" description ="Number of Classes">
      <Values per = "packageFragment" total = "23" avg = "7.667" stddev = "4.989" max = "13">
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="13"/>
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="9"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NOI" description ="Number of Interfaces">
      <Values per = "packageFragment" total = "12" avg = "4" stddev = "3.742" max = "9">
         <Value name="org.netbeans.spi.java.queries" package ="org.netbeans.spi.java.queries" value ="9"/>
         <Value name="org.netbeans.api.java.queries" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="org.netbeans.api.java.classpath" package ="org.netbeans.api.java.classpath" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOP" description ="Number of Packages">
      <Value value="3"/>
   </Metric>
   <Metric id = "TLOC" description ="Total Lines of Code">
      <Value value="459"/>
   </Metric>
   <Metric id = "MLOC" description ="Method Lines of Code">
      <Values per = "method" total = "237" avg = "3.885" stddev = "7.284" max = "36">
         <Value name="attach" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="36"/>
         <Value name="getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="27"/>
         <Value name="SourceLevelQuery.Result#addChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="22"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="17"/>
         <Value name="getSourceLevel2" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="16"/>
         <Value name="findSources" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="16"/>
         <Value name="findUnitTests" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="16"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="14"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="9"/>
         <Value name="attachSources" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="9"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="8"/>
         <Value name="SourceLevelQuery.Result#removeChangeListener" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="SourceLevelQuery.Result#supportsChanges" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="6"/>
         <Value name="findSource" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="5"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="5"/>
         <Value name="normalize" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="4"/>
         <Value name="AnnotationProcessingQuery.Result#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="3"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="SourceLevelQuery.Result#Result" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="2"/>
         <Value name="AnnotationProcessingQuery.Result#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.Result#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#annotationProcessorsToRun" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#processorOptions" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result.anonymous#~addChangeListener~QChangeListener;[#stateChanged" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#getDelegate" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="SourceLevelQuery.Result#getSourceLevel" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="1"/>
         <Value name="findJavadoc" source ="JavadocForBinaryQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="SourceLevelQueryImplementation2.Result#getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="getSourceLevel" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="1"/>
         <Value name="AccessibilityQuery" source ="AccessibilityQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#annotationProcessingEnabled" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.Result#sourceOutputDirectory" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#addChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery.anonymous#^EMPTY[#removeChangeListener" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="AnnotationProcessingQuery" source ="AnnotationProcessingQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#EmptyResult" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.EmptyResult#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#addChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#getRoots" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery.Result#removeChangeListener" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="JavadocForBinaryQuery" source ="JavadocForBinaryQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.AttachmentListener#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentFailed" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceJavadocAttacher.anonymous#~attach~QURL;~QAttachmentListener;~I[#attachmentSucceeded" source ="SourceJavadocAttacher.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="SourceLevelQuery" source ="SourceLevelQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="UnitTestForSourceQuery" source ="UnitTestForSourceQuery.java" package ="org.netbeans.api.java.queries" value ="0"/>
         <Value name="isPubliclyAccessible" source ="AccessibilityQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="getAnnotationProcessingOptions" source ="AnnotationProcessingQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findSources" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findUnitTests" source ="MultipleRootsUnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="attachJavadoc" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="attachSources" source ="SourceJavadocAttacherImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#addChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="SourceLevelQueryImplementation2.Result#removeChangeListener" source ="SourceLevelQueryImplementation2.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findSource" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
         <Value name="findUnitTest" source ="UnitTestForSourceQueryImplementation.java" package ="org.netbeans.spi.java.queries" value ="0"/>
      </Values>
   </Metric>
   </Metrics>
