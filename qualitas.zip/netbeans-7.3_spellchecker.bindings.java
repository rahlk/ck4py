<?xml version="1.0" encoding="UTF-8"?>
<Metrics scope="netbeans-7.3_spellchecker.bindings.java" type="Project" date="2013-06-19" xmlns="http://metrics.sourceforge.net/2003/Metrics-First-Flat">
   <Metric id = "VG" description ="McCabe Cyclomatic Complexity" max ="10" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "3.306" stddev = "5.082" max = "28" maxinrange="false">
         <Value name="wordBroker" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="28" inrange="false"/>
         <Value name="nextWordImpl" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="16" inrange="false"/>
         <Value name="handleJavadocTag" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="7"/>
         <Value name="findTokenList" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="7"/>
         <Value name="separateWords" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="6"/>
         <Value name="setStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="5"/>
         <Value name="findNextJavaDocComment" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="5"/>
         <Value name="get" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="handleIdentifier" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="nextWord" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.TaskImpl#run" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="isIdentifierLike" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="getCurrentWordText" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="nextWord" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="startsWith" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#createTask" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitClass" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitMethod" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitVariable" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl#cancel" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="set" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList.Pair#Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordText" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="isLetter" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="setStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "PAR" description ="Number of Parameters" max ="5" hint ="Move invoked method or pass an object">
      <Values per = "method" avg = "1.028" stddev = "0.957" max = "4">
         <Value name="handleIdentifier" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="wordBroker" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitClass" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitMethod" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitVariable" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="separateWords" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="set" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenList.Pair#Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="startsWith" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#createTask" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl#run" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="get" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="setStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="handleJavadocTag" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="isIdentifierLike" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="isLetter" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="setStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="findTokenList" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl#cancel" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="getCurrentWordStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="getCurrentWordText" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="nextWord" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="findNextJavaDocComment" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="getCurrentWordStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="getCurrentWordText" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="nextWord" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="nextWordImpl" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NBD" description ="Nested Block Depth" max ="5" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "1.778" stddev = "1.25" max = "6" maxinrange="false">
         <Value name="nextWordImpl" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="6" inrange="false"/>
         <Value name="separateWords" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="5"/>
         <Value name="handleJavadocTag" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="findTokenList" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="handleIdentifier" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="findNextJavaDocComment" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="wordBroker" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl#run" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="getCurrentWordText" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="get" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="setStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="isIdentifierLike" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="nextWord" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="startsWith" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#createTask" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitClass" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitMethod" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitVariable" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl#cancel" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="nextWord" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="set" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList.Pair#Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordText" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="isLetter" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="setStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "CA" description ="Afferent Coupling">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "CE" description ="Efferent Coupling">
      <Values per = "packageFragment" avg = "3" stddev = "0" max = "3">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
      </Values>
   </Metric>
   <Metric id = "RMI" description ="Instability">
      <Values per = "packageFragment" avg = "1" stddev = "0" max = "1">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "RMA" description ="Abstractness">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMD" description ="Normalized Distance">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "DIT" description ="Depth of Inheritance Tree">
      <Values per = "type" avg = "1.429" stddev = "0.728" max = "3">
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "WMC" description ="Weighted methods per Class">
      <Values per = "type" total = "119" avg = "17" stddev = "24.042" max = "72">
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="72"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="28"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="8"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSC" description ="Number of Children">
      <Values per = "type" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NORM" description ="Number of Overridden Methods">
      <Values per = "type" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "LCOM" description ="Lack of Cohesion of Methods">
      <Values per = "type" avg = "0.194" stddev = "0.312" max = "0.778">
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0.778"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0.583"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOF" description ="Number of Attributes">
      <Values per = "type" total = "17" avg = "2.429" stddev = "3.017" max = "9">
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="9"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSF" description ="Number of Static Attributes">
      <Values per = "type" total = "4" avg = "0.571" stddev = "0.728" max = "2">
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOM" description ="Number of Methods">
      <Values per = "type" total = "31" avg = "4.429" stddev = "3.774" max = "12">
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="12"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="8"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSM" description ="Number of Static Methods">
      <Values per = "type" total = "5" avg = "0.714" stddev = "1.161" max = "3">
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "SIX" description ="Specialization Index">
      <Values per = "type" avg = "0" stddev = "0" max = "0">
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenList.Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOC" description ="Number of Classes">
      <Values per = "packageFragment" total = "7" avg = "7" stddev = "0" max = "7">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="7"/>
      </Values>
   </Metric>
   <Metric id = "NOI" description ="Number of Interfaces">
      <Values per = "packageFragment" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.spellchecker.bindings.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOP" description ="Number of Packages">
      <Value value="1"/>
   </Metric>
   <Metric id = "TLOC" description ="Total Lines of Code">
      <Value value="454"/>
   </Metric>
   <Metric id = "MLOC" description ="Method Lines of Code">
      <Values per = "method" total = "295" avg = "8.194" stddev = "14.468" max = "74">
         <Value name="wordBroker" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="74"/>
         <Value name="nextWordImpl" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="49"/>
         <Value name="separateWords" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="24"/>
         <Value name="handleJavadocTag" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="21"/>
         <Value name="findTokenList" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="14"/>
         <Value name="JavaSemanticTokenList.TaskImpl#run" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="12"/>
         <Value name="get" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="12"/>
         <Value name="findNextJavaDocComment" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="12"/>
         <Value name="handleIdentifier" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="11"/>
         <Value name="setStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="8"/>
         <Value name="getCurrentWordText" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="7"/>
         <Value name="isIdentifierLike" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="7"/>
         <Value name="nextWord" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="6"/>
         <Value name="setStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="6"/>
         <Value name="startsWith" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="4"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitClass" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitMethod" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#visitVariable" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="set" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="3"/>
         <Value name="JavaSemanticTokenList.TaskImpl.ScannerImpl#ScannerImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="getCurrentWordStartOffset" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="nextWord" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaTokenList.Pair#Pair" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="2"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#FactoryImpl" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.FactoryImpl#createTask" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="addChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="removeChangeListener" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaTokenList" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordStartOffset" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="getCurrentWordText" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="isLetter" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="1"/>
         <Value name="JavaSemanticTokenList.TaskImpl#cancel" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaSemanticTokenList" source ="JavaSemanticTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="addChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="removeChangeListener" source ="JavaTokenList.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
         <Value name="JavaTokenListProvider" source ="JavaTokenListProvider.java" package ="org.netbeans.modules.spellchecker.bindings.java" value ="0"/>
      </Values>
   </Metric>
   </Metrics>
