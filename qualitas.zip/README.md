# Qualitas

Compiled code smells dataset.
