<?xml version="1.0" encoding="UTF-8"?>
<Metrics scope="netbeans-7.3_maven.groovy" type="Project" date="2013-06-19" xmlns="http://metrics.sourceforge.net/2003/Metrics-First-Flat">
   <Metric id = "VG" description ="McCabe Cyclomatic Complexity" max ="10" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "2.062" stddev = "1.547" max = "7">
         <Value name="createReplacements" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="7"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#propertyChange" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="6"/>
         <Value name="groovyEclipseCompilerExists" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="mavenCompilerPluginExists" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="updateDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="convert" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="updateConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="createSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="performOperation" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="performOperation" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="isGroovyFile" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#keys" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="performOperation" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="activate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="isActive" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous##performOperation" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="getPrivilegedTemplates" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="isInTestFolder" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="addGroupIfRootExists" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="getSourceGroups" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#checkFileObject" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#getJavaRoots" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeListener" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="createConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="deactivate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="kind" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addSourcesGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addTestGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="canCreateSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="removeChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#addNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileAttributeChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDataCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDeleted" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileFolderCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileRenamed" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#node" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="createNodes" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "PAR" description ="Number of Parameters" max ="5" hint ="Move invoked method or pass an object">
      <Values per = "method" avg = "0.938" stddev = "0.747" max = "4">
         <Value name="addGroupIfRootExists" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="updateConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="updateDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="convert" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="createReplacements" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="canCreateSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="createSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="performOperation" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="groovyEclipseCompilerExists" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="performOperation" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="mavenCompilerPluginExists" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="performOperation" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous##performOperation" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="isGroovyFile" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="isInTestFolder" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addSourcesGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addTestGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="getSourceGroups" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="removeChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#checkFileObject" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileAttributeChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDataCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDeleted" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileFolderCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileRenamed" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#node" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#propertyChange" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeListener" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="createNodes" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="createConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="createDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="activate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="deactivate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="isActive" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="getPrivilegedTemplates" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="kind" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#addNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#getJavaRoots" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#keys" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NBD" description ="Nested Block Depth" max ="5" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "1.875" stddev = "1.201" max = "5">
         <Value name="isActive" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="createReplacements" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="groovyEclipseCompilerExists" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="mavenCompilerPluginExists" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="updateConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="updateDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="convert" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#propertyChange" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="activate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#keys" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="performOperation" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="performOperation" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="performOperation" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous##performOperation" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="getPrivilegedTemplates" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="isGroovyFile" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="isInTestFolder" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="addGroupIfRootExists" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="createSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="getSourceGroups" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#checkFileObject" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#getJavaRoots" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeListener" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="createConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="deactivate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="kind" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addSourcesGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addTestGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="canCreateSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="removeChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#addNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileAttributeChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDataCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDeleted" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileFolderCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileRenamed" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#node" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="createNodes" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "CA" description ="Afferent Coupling">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "CE" description ="Efferent Coupling">
      <Values per = "packageFragment" avg = "4.5" stddev = "0.5" max = "5">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
      </Values>
   </Metric>
   <Metric id = "RMI" description ="Instability">
      <Values per = "packageFragment" avg = "1" stddev = "0" max = "1">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "RMA" description ="Abstractness">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMD" description ="Normalized Distance">
      <Values per = "packageFragment" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "DIT" description ="Depth of Inheritance Tree">
      <Values per = "type" avg = "1.1" stddev = "0.3" max = "2">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "WMC" description ="Weighted methods per Class">
      <Values per = "type" total = "99" avg = "9.9" stddev = "8.491" max = "25">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="25"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="21"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="18"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="14"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="8"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="6"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSC" description ="Number of Children">
      <Values per = "type" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NORM" description ="Number of Overridden Methods">
      <Values per = "type" total = "2" avg = "0.2" stddev = "0.6" max = "2">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "LCOM" description ="Lack of Cohesion of Methods">
      <Values per = "type" avg = "0.111" stddev = "0.224" max = "0.611">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0.611"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0.5"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOF" description ="Number of Attributes">
      <Values per = "type" total = "9" avg = "0.9" stddev = "0.943" max = "3">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSF" description ="Number of Static Attributes">
      <Values per = "type" total = "24" avg = "2.4" stddev = "1.744" max = "5">
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOM" description ="Number of Methods">
      <Values per = "type" total = "48" avg = "4.8" stddev = "4.377" max = "15">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="15"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="9"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="8"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="2"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSM" description ="Number of Static Methods">
      <Values per = "type" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "SIX" description ="Specialization Index">
      <Values per = "type" avg = "0.027" stddev = "0.08" max = "0.267">
         <Value name="GroovySourcesNodeFactory.GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0.267"/>
         <Value name="AddGroovyDependency" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddGroovyEclipseCompiler" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="AddMavenCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous#" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovyRootProvider" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOC" description ="Number of Classes">
      <Values per = "packageFragment" total = "10" avg = "5" stddev = "1" max = "6">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="6"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="4"/>
      </Values>
   </Metric>
   <Metric id = "NOI" description ="Number of Interfaces">
      <Values per = "packageFragment" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.maven.groovy" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="org.netbeans.modules.maven.groovy.extender" package ="org.netbeans.modules.maven.groovy.extender" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOP" description ="Number of Packages">
      <Value value="2"/>
   </Metric>
   <Metric id = "TLOC" description ="Total Lines of Code">
      <Value value="578"/>
   </Metric>
   <Metric id = "MLOC" description ="Method Lines of Code">
      <Values per = "method" total = "302" avg = "6.292" stddev = "6.548" max = "26">
         <Value name="updateConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="26"/>
         <Value name="createReplacements" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="26"/>
         <Value name="isActive" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="22"/>
         <Value name="performOperation" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="15"/>
         <Value name="performOperation" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="15"/>
         <Value name="updateDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="15"/>
         <Value name="activate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="15"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#propertyChange" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="13"/>
         <Value name="convert" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="11"/>
         <Value name="groovyEclipseCompilerExists" source ="AddGroovyEclipseCompiler.java" package ="org.netbeans.modules.maven.groovy.extender" value ="10"/>
         <Value name="mavenCompilerPluginExists" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="10"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="10"/>
         <Value name="createSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="10"/>
         <Value name="performOperation" source ="AddGroovyDependency.java" package ="org.netbeans.modules.maven.groovy.extender" value ="9"/>
         <Value name="getPrivilegedTemplates" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="9"/>
         <Value name="getSourceGroups" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="8"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#keys" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="8"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="7"/>
         <Value name="createMavenEclipseCompilerPlugin" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="6"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#addNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="6"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeNotify" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="6"/>
         <Value name="createDependency" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="MavenGroovyExtender.anonymous#~activate[#run" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="MavenGroovyExtender.anonymous#~isActive[.anonymous##performOperation" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="5"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#checkFileObject" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#getJavaRoots" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="5"/>
         <Value name="isGroovyFile" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="isInTestFolder" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="addGroupIfRootExists" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#removeListener" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="4"/>
         <Value name="createConfiguration" source ="AddMavenCompilerPlugin.java" package ="org.netbeans.modules.maven.groovy.extender" value ="3"/>
         <Value name="addSourcesGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="addTestGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="3"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#GroovyNodeList" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDeleted" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="2"/>
         <Value name="MavenGroovyExtender" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="deactivate" source ="MavenGroovyExtender.java" package ="org.netbeans.modules.maven.groovy.extender" value ="1"/>
         <Value name="GroovyPrivs" source ="GroovyPrivs.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovyReplaceTokenProvider" source ="GroovyReplaceTokenProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="kind" source ="GroovyRootProvider.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesImpl" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="canCreateSourceGroup" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileFolderCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileRenamed" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#node" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="createNodes" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="1"/>
         <Value name="addChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="removeChangeListener" source ="GroovySourcesImpl.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileAttributeChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileChanged" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
         <Value name="GroovySourcesNodeFactory.GroovyNodeList#fileDataCreated" source ="GroovySourcesNodeFactory.java" package ="org.netbeans.modules.maven.groovy" value ="0"/>
      </Values>
   </Metric>
   </Metrics>
