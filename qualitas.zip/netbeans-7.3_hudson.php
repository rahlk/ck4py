<?xml version="1.0" encoding="UTF-8"?>
<Metrics scope="netbeans-7.3_hudson.php" type="Project" date="2013-06-14" xmlns="http://metrics.sourceforge.net/2003/Metrics-First-Flat">
   <Cycle name="org.netbeans.modules.hudson.php.commands et al" nodes="3" diameter="2">
      <Package>org.netbeans.modules.hudson.php.commands</Package>
      <Package>org.netbeans.modules.hudson.php.options</Package>
      <Package>org.netbeans.modules.hudson.php.ui.options</Package>
   </Cycle>
   <Metric id = "VG" description ="McCabe Cyclomatic Complexity" max ="10" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "1.554" stddev = "1.274" max = "10">
         <Value name="status" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="10"/>
         <Value name="processBuildXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="6"/>
         <Value name="createProjectFiles" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="5"/>
         <Value name="initTargetComponent" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="5"/>
         <Value name="getPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="4"/>
         <Value name="asString" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="4"/>
         <Value name="query" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="4"/>
         <Value name="setupProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="4"/>
         <Value name="relativizePath" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="3"/>
         <Value name="getJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="3"/>
         <Value name="validateJobConfig" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="3"/>
         <Value name="isValid" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="createJobXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="informUser" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="removeNodes" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="getDefault" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="getDefaultJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="commentNode" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="jobConfigBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#accept" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="jobConfigDownloadLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="jobConfigLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwSearchButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="getComponent" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="stateChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonJobCreator.Factory#forProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="initComponents" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="validate" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptions.anonymous#[#preferenceChange" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getInstance" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getPreferences" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getName" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="all" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#processUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="checkDefaultButtonState" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="fireChange" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="init" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="initComponents" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#getDescription" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDefaultButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDownloadLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#detect" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getListTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getNoItemsFound" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getPleaseWaitPart" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getWindowTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setError" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setWarning" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addPropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="applyChanges" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="cancel" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getHelpCtx" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptions" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptionsPath" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="isChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removePropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="update" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="commentNode" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="getNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="parse" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[#resolveEntity" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="save" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="setNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="addChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="configure" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="customizer" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="errorOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="finishLayout" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="forPhpModule" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getJobConfig" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getOpenHudsonOptionsButton" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="jobName" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="stateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="warningOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "PAR" description ="Number of Parameters" max ="5" hint ="Move invoked method or pass an object">
      <Values per = "method" avg = "0.652" stddev = "0.752" max = "3">
         <Value name="setNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="3"/>
         <Value name="errorOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="informUser" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="createProjectFiles" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="relativizePath" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="commentNode" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="asString" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="commentNode" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="getNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[#resolveEntity" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="query" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="save" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="initTargetComponent" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="removeNodes" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="validate" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions.anonymous#[#preferenceChange" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="validateJobConfig" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="apply" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#accept" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDefaultButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDownloadLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDownloadLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwSearchButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setError" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setWarning" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addPropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getComponent" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removePropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="stateChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="parse" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator.Factory#forProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="addChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="finishLayout" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="forPhpModule" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="stateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="warningOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getDefault" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getDefaultJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getInstance" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getPreferences" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="getName" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getOptions" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="isEnabled" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="all" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getOptions" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="isEnabled" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="isSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#processUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="checkDefaultButtonState" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="fireChange" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="getJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="getPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="init" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="initComponents" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#getDescription" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#detect" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getListTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getNoItemsFound" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getPleaseWaitPart" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getWindowTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="applyChanges" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="cancel" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="getHelpCtx" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="getOptions" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="getOptionsPath" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="isChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="isValid" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="update" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="configure" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="createJobXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="customizer" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="getJobConfig" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="getOpenHudsonOptionsButton" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="initComponents" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="jobName" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="processBuildXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="setupProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="status" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NBD" description ="Nested Block Depth" max ="5" hint ="use Extract-method to split the method up">
      <Values per = "method" avg = "1.42" stddev = "0.752" max = "4">
         <Value name="parse" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="4"/>
         <Value name="processBuildXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="4"/>
         <Value name="createProjectFiles" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="3"/>
         <Value name="getJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="3"/>
         <Value name="getPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="3"/>
         <Value name="jobConfigBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="asString" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="3"/>
         <Value name="query" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="3"/>
         <Value name="save" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="3"/>
         <Value name="initTargetComponent" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="removeNodes" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="setupProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="getDefault" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="relativizePath" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="getDefaultJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="validateJobConfig" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="commentNode" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="init" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="initComponents" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#accept" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="jobConfigDownloadLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="jobConfigLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="ppwSearchButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="getComponent" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="isValid" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="stateChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonJobCreator.Factory#forProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="createJobXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="getOpenHudsonOptionsButton" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="informUser" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="initComponents" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="status" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="validate" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions.anonymous#[#preferenceChange" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getInstance" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getPreferences" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getName" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="all" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#processUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="checkDefaultButtonState" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="fireChange" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#getDescription" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDefaultButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDownloadLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#detect" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getListTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getNoItemsFound" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getPleaseWaitPart" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getWindowTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setError" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setWarning" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addPropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="applyChanges" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="cancel" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getHelpCtx" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptions" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptionsPath" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="isChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removePropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="update" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="commentNode" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="getNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[#resolveEntity" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="setNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="addChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="configure" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="customizer" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="errorOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="finishLayout" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="forPhpModule" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getJobConfig" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="jobName" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="stateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="warningOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getName" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "CA" description ="Afferent Coupling">
      <Values per = "packageFragment" avg = "2.333" stddev = "1.7" max = "5">
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="5"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="4"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "CE" description ="Efferent Coupling">
      <Values per = "packageFragment" avg = "2.167" stddev = "1.772" max = "6">
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="6"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "RMI" description ="Instability">
      <Values per = "packageFragment" avg = "0.532" stddev = "0.299" max = "1">
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="0.857"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="0.5"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="0.333"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="0.333"/>
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="0.167"/>
      </Values>
   </Metric>
   <Metric id = "RMA" description ="Abstractness">
      <Values per = "packageFragment" avg = "0.028" stddev = "0.062" max = "0.167">
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="0.167"/>
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "RMD" description ="Normalized Distance">
      <Values per = "packageFragment" avg = "0.448" stddev = "0.323" max = "0.833">
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="0.833"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="0.667"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="0.667"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="0.5"/>
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="0.024"/>
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "DIT" description ="Depth of Inheritance Tree">
      <Values per = "type" avg = "1.933" stddev = "1.289" max = "5">
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="5"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "WMC" description ="Weighted methods per Class">
      <Values per = "type" total = "174" avg = "11.6" stddev = "12.579" max = "49">
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="49"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="29"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="16"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="16"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="15"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="14"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="12"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="4"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="4"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="4"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="3"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSC" description ="Number of Children">
      <Values per = "type" total = "5" avg = "0.333" stddev = "1.247" max = "5">
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="5"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NORM" description ="Number of Overridden Methods">
      <Values per = "type" total = "3" avg = "0.2" stddev = "0.542" max = "2">
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "LCOM" description ="Lack of Cohesion of Methods">
      <Values per = "type" avg = "0.25" stddev = "0.359" max = "0.937">
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0.937"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0.833"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0.688"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0.667"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0.619"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOF" description ="Number of Attributes">
      <Values per = "type" total = "34" avg = "2.267" stddev = "5.183" max = "21">
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="21"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="4"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="3"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NSF" description ="Number of Static Attributes">
      <Values per = "type" total = "21" avg = "1.4" stddev = "2.123" max = "7">
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="7"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="5"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="4"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOM" description ="Number of Methods">
      <Values per = "type" total = "98" avg = "6.533" stddev = "6.83" max = "23">
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="23"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="20"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="12"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="11"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="9"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="4"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="4"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="3"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="3"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NSM" description ="Number of Static Methods">
      <Values per = "type" total = "14" avg = "0.933" stddev = "1.731" max = "7">
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="7"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="2"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "SIX" description ="Specialization Index">
      <Values per = "type" avg = "0.111" stddev = "0.29" max = "1">
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="PhpcsTarget" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="PhpdocTarget" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0.667"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptions.anonymous#[" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="PhpcpdTarget" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhplocTarget" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="PhpmdTarget" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="HudsonOptionsPanelController" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.Factory" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOC" description ="Number of Classes">
      <Values per = "packageFragment" total = "15" avg = "2.5" stddev = "1.708" max = "6">
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="6"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="2"/>
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
      </Values>
   </Metric>
   <Metric id = "NOI" description ="Number of Interfaces">
      <Values per = "packageFragment" total = "0" avg = "0" stddev = "0" max = "0">
         <Value name="org.netbeans.modules.hudson.php" package ="org.netbeans.modules.hudson.php" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.commands" package ="org.netbeans.modules.hudson.php.commands" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.options" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.support" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.ui.options" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="org.netbeans.modules.hudson.php.xml" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
      </Values>
   </Metric>
   <Metric id = "NOP" description ="Number of Packages">
      <Value value="6"/>
   </Metric>
   <Metric id = "TLOC" description ="Total Lines of Code">
      <Value value="1229"/>
   </Metric>
   <Metric id = "MLOC" description ="Method Lines of Code">
      <Values per = "method" total = "680" avg = "6.071" stddev = "13.308" max = "116">
         <Value name="initComponents" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="116"/>
         <Value name="initTargetComponent" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="48"/>
         <Value name="createProjectFiles" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="36"/>
         <Value name="status" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="34"/>
         <Value name="init" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="32"/>
         <Value name="ppwSearchButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="31"/>
         <Value name="jobConfigBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="24"/>
         <Value name="processBuildXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="18"/>
         <Value name="parse" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="17"/>
         <Value name="validateJobConfig" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="16"/>
         <Value name="asString" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="16"/>
         <Value name="query" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="16"/>
         <Value name="createJobXml" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="14"/>
         <Value name="getOpenHudsonOptionsButton" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="14"/>
         <Value name="setupProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="13"/>
         <Value name="isValid" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="12"/>
         <Value name="save" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="11"/>
         <Value name="getPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="10"/>
         <Value name="relativizePath" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="8"/>
         <Value name="getJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="8"/>
         <Value name="ppwBrowseButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="8"/>
         <Value name="initComponents" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="8"/>
         <Value name="all" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="7"/>
         <Value name="commentNode" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="7"/>
         <Value name="finishLayout" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="7"/>
         <Value name="getDefault" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="6"/>
         <Value name="HudsonOptions" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="6"/>
         <Value name="getDefaultJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="6"/>
         <Value name="jobConfigDownloadLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="6"/>
         <Value name="removeNodes" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="6"/>
         <Value name="jobConfigLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="ppwLearnMoreLabelMousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="getComponent" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="stateChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="5"/>
         <Value name="HudsonJobCreator.Factory#forProject" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="5"/>
         <Value name="informUser" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="5"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="4"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#accept" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="4"/>
         <Value name="forPhpModule" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="4"/>
         <Value name="setError" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="setWarning" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="applyChanges" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="update" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="3"/>
         <Value name="HudsonJobCreator" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="3"/>
         <Value name="HudsonOptionsPanel" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="2"/>
         <Value name="commentNode" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="2"/>
         <Value name="configure" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="errorOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="2"/>
         <Value name="PpwScript" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="validate" source ="PpwScript.java" package ="org.netbeans.modules.hudson.php.commands" value ="1"/>
         <Value name="HudsonOptions.anonymous#[#preferenceChange" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getInstance" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getPreferences" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptions.java" package ="org.netbeans.modules.hudson.php.options" value ="1"/>
         <Value name="getName" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcpdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="apply" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpcsTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="PhpdocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhplocTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getName" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getTitleWithMnemonic" source ="PhpmdTarget.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getOptions" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="getSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isEnabled" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="isSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelectedOption" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="setSelected" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#processUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.DefaultDocumentListener#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="checkDefaultButtonState" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="fireChange" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!2#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!3#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!4#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!5#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!6#actionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!7#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[!8#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~initComponents[#mousePressed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#changedUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#insertUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~init[#removeUpdate" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~jobConfigBrowseButtonActionPerformed~QActionEvent;[#getDescription" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDefaultButtonActionPerformed" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigDownloadLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="jobConfigLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="ppwLearnMoreLabelMouseEntered" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#detect" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getListTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getNoItemsFound" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getPleaseWaitPart" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="HudsonOptionsPanel.anonymous#~ppwSearchButtonActionPerformed~QActionEvent;[#getWindowTitle" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setJobConfig" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="setPpw" source ="HudsonOptionsPanel.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="addPropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getHelpCtx" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptions" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getOptionsPath" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="isChanged" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="removePropertyChangeListener" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="1"/>
         <Value name="getNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="XmlUtils.anonymous#~parse~QFile;[#resolveEntity" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="setNodeValue" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="1"/>
         <Value name="addChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="customizer" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="getJobConfig" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~getOpenHudsonOptionsButton[#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!2#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[!3#actionPerformed" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonJobCreator.anonymous#~initTargetComponent~I~QTarget;[#itemStateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="jobName" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="removeChangeListener" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="stateChanged" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="warningOccured" source ="HudsonJobCreator.java" package ="org.netbeans.modules.hudson.php" value ="1"/>
         <Value name="HudsonOptionsValidator" source ="HudsonOptionsValidator.java" package ="org.netbeans.modules.hudson.php.options" value ="0"/>
         <Value name="Target" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="apply" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getName" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="getTitleWithMnemonic" source ="Target.java" package ="org.netbeans.modules.hudson.php.support" value ="0"/>
         <Value name="cancel" source ="HudsonOptionsPanelController.java" package ="org.netbeans.modules.hudson.php.ui.options" value ="0"/>
         <Value name="XmlUtils" source ="XmlUtils.java" package ="org.netbeans.modules.hudson.php.xml" value ="0"/>
      </Values>
   </Metric>
   </Metrics>
