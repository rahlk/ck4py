# `react-native-renderer`

This package is the renderer that is used by the react-native package.
It is intended to be used inside the react-native environment. It is not
intended to be used stand alone.
