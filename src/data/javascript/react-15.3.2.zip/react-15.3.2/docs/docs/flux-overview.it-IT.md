---
id: flux-overview-it-IT
title: Architettura di un'Applicazione Flux
permalink: docs/flux-overview-it-IT.html
---

Questa pagina è stata spostata sul sito di Flux. [Leggila qui](https://facebook.github.io/flux/docs/overview.html).
