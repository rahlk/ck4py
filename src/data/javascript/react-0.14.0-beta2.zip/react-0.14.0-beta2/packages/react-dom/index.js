module.exports = require('react/lib/ReactDOM');
