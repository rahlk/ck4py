module.exports = require('./lib/React');
