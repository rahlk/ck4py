---
layout: default
title: JSX Compiler Service
id: jsx-compiler
---
<div class="jsxCompiler">
  <h1>JSX Compiler</h1>
  <p>
    This tool demonstrates how <a href="/react/docs/jsx-in-depth.html">JSX syntax</a>
    is desugared into native JavaScript.
  </p>
  <div id="jsxCompiler"></div>
  <script type="text/javascript" src="js/jsx-compiler.js"></script>
</div>
