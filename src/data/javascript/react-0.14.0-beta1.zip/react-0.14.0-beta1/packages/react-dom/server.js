module.exports = require('react/lib/ReactDOMServer');
