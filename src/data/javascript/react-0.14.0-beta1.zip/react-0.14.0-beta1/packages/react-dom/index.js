module.exports = require('react/lib/ReactDOMClient');
