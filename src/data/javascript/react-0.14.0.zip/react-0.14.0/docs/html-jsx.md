---
layout: default
title: HTML to JSX
id: html-jsx
---
<div class="jsxCompiler">
  <h1>HTML to JSX Compiler</h1>
  <div id="jsxCompiler"></div>
  <script src="https://reactjs.github.io/react-magic/htmltojsx.min.js"></script>
  <script src="js/html-jsx.js"></script>
</div>
