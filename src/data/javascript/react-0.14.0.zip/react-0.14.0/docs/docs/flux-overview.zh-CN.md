---
id: flux-overview-zh-CN
title: Flux 应用架构
permalink: flux-overview-zh-CN.html
---

本页被移到了 Flux 网站。[点击访问](https://facebook.github.io/flux/docs/overview.html)。
