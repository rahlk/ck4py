---
layout: single
title: JSX Compiler Service
id: jsx-compiler
---

**_This tool has been removed as JSXTransformer has been deprecated._**

We recommend using another tool such as [the Babel REPL](https://babeljs.io/repl/).
