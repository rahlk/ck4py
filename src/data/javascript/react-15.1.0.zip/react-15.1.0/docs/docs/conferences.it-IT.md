---
id: conferences-it-IT
title: Conferenze
permalink: conferences-it-IT.html
prev: thinking-in-react-it-IT.html
next: videos-it-IT.html
---

### React.js Conf 2015
28 e 29 Gennaio

[Sito web](http://conf.reactjs.com/) - [Agenda](http://conf.reactjs.com/schedule.html) - [Video](https://www.youtube-nocookie.com/playlist?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr)

<iframe width="650" height="315" src="//www.youtube-nocookie.com/embed/KVZ-P-ZI6W4?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr" frameborder="0" allowfullscreen></iframe>

### ReactEurope 2015
2 e 3 Luglio

[Sito web](http://www.react-europe.org/) - [Agenda](http://www.react-europe.org/#schedule)
