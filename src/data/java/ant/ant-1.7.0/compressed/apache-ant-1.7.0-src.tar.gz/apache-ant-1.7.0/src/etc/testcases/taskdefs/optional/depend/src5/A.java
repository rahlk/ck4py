public class A {
    APrivate dependency = new APrivate();
}

class APrivate extends B {
}
