package test;

public class Outer {
    static class Inner {
    }
}

